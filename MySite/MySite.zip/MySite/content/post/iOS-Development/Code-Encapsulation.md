+++
date = "2017-08-03T18:42:45+08:00"
title = "Code Encapsulation"
Tags = ["iOS-Development"]
+++

明天开始吧，⛽️

# References

[封装](https://baike.baidu.com/item/封装/2796965?fr=aladdin)

[程序封装思想和常见原则](https://wenku.baidu.com/view/bf47587eba1aa8114531d900.html)

[设计模式之单一职责原则（iOS开发，代码用Objective-C展示）](http://www.cnblogs.com/ziyi--caolu/p/4800825.html)

[IOS 开发学习总结objective-c面向对象之——封装和访问控制符](http://www.2cto.com/kf/201509/443782.html)

[iOS封装浅析](http://www.jianshu.com/p/1ea86b79cbfb)

[iOS常用的封装方法](http://www.cnblogs.com/leixu/p/5287313.html)

[对可变性的封装原则](http://www.cnblogs.com/feng9exe/p/5592494.html)

[我所认识的软件开发原则：封装](http://blog.csdn.net/suncherrydream/article/details/38982299)

[面向对象程序设计](https://baike.baidu.com/item/面向对象程序设计/24792?fr=aladdin&fromid=254878&fromtitle=面向对象编程)


