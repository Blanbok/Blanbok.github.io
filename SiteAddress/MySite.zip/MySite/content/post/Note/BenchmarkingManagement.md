+++
title = "Benchmarking"
date = "2017-08-03T16:48:42+08:00"
description = "做下关于自己的对标管理来着。"
Tags = ["note"]
+++

> 找到目标(一个好的项目，希望达到的知识水平和目标的人)

> 对标准的分析(有用的东西，如知识、习惯等)

> 对标差距(当前与目标的差距)

> 行动计划(实现目标实施计划)

> 下一步(下一个步骤可以直接开始，设置开始时间、周期、最后期限)

# 一、[My30DaysofSwift-4.0](https://github.com/Blanbok/My30DaysofSwift-4.0)
  
1. 目标
- 学会swift语言的基本用法
- 将Swift语言的掌握情况与Object-C同步

2. 对标分析
- 已有基础：Swift的原型，Object-C的开发经验
- 需要掌握：Swift的关键字，Swift与Object-C的联系

3. 行动计划
- 时间期限：2017.07.18-2017.07.30
- 行动过程：仿照[30DaysofSwift](https://github.com/allenwong/30DaysofSwift)制订自己的30天学习计划[My30DaysofSwift-4.0](https://github.com/Blanbok/My30DaysofSwift-4.0)

4. 完成情况
- 2017.07.18 开始进行
- 2017.07.21 原定目标基本完成
- 原项目结束，2017.07.24 拓展项目[One-day-one-project](https://github.com/Blanbok/One-day-one-project)开始

5. 自省改善
- 除原定计划外，可以制定增加拓展计划以应对计划过早完成的情况
- 通过原定计划的发散思考，在项目计划表中对发散项目进行排期

6. 拓展计划
- 将仿照的项目完整完成
- 对于新出的功能列小项目进行针对性的实践

7. 发散思考
- 过往需要掌握的功能点通过每日小项目进行掌握
- 参考其它优秀的进步计划来优化自己的提升计划

# 二、60 days English mastery
1. 目标
- 掌握英文基本听说读写
- 翻译阅读英文原文

2. 对标分析
- 已有基础：英文基本字符的掌握
- 需要掌握：英文单词储备，英文听说能力提升

3. 行动计划
- 时间期限：2017.07.23-2017.09.30
- 行动过程：一周内提升单词储备，一周后进行英文原文阅读，储备时间增加为一个月即 07.23～08.23

4. 完成情况
- 2017.07.23 开始实施 通过`沪江开心词场`开始练习
- 2017.07.30 计划改变，前期准备时间增加，总时间增加

# 三、[One-project-one-plan](https://github.com/Blanbok/One-day-one-project)

1. 目标
- It's never too late to learn
- 保持前行

2. 完成情况
- 2017.07.24 开始进行
- 2017.07.30 更改执行步骤


