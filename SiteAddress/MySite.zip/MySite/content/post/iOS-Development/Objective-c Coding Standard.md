+++
date = "2017-08-06T22:20:23+08:00"
title = "Objective-c Coding Standard"
Tags = ["iOS-Development"]
+++

此次规范从当前的开发现状（风格各异）出发，奠基于当前的编码习惯，旨在规范大家的编程行为。
待到下次开会的时候，仍需依据自己的习惯，提出针对性的意见。后期将参考此次会上的意见进行修订。

> 最近大佬要规范下团队里的编码规范，作为狗腿子的咱自然是要响应下号召咯...顺带的自己也想把规范定下来，后面一步步的修订，方便代码更新迭代。
> 还是想着能让自己代码更加的简洁、明了、具有表达力的😁
> 希望下次谁谁看代码的时候，不用特意去对照界面就能了解这是个做什么的。

-------

# 一- 资料参考

我们所写的代码主要是为了阅读，其次才是被机器执行。所以我们要写：

- 让别人能读懂的代码
- 可扩展的代码
- 可测试的代码(代码应该具备可测试性，对没有可测试性的代码写测试，是浪费生命的表现)

## 1、编程原则

许多刚步入编程之路的人，总喜欢鼓吹各种各样的“原则”

### (1) RC原则

> 可读性高(Readable)
> 防止命名冲突(Conflict Name prevention)

### (2) TEDC原则
> 简洁(Terse)
> 具有表达力(Expressive)
> 只做一件事(Do one thing)

### (3) DRY原则

> Don't Repeat Yourself

### (4) KISS原则

> Keep it Simple and Stupid

### 总结

许多刚步入编程门槛的程序员，总喜欢泛谈编程原则，将这些奉为教条或者秘方，觉得这些原则就是编程的捷径，能够直达编程之巅。

实际如此吗？很明显不是的，若真遵守几个原则就可以成为一个合格的程序员，那程序员岂不是太不值钱啦！(虽然事实就是如此😦)

所谓原则，更多的是供我们参考的一个经典思路，以供我们打开脑洞的。（先摸摸看你的脑袋能开多大的洞😄）

从来都没有“万金油”的代码，要想进行某项优化，则必会有相应的风险。

而我们在实际编程中所要积累的经验，正是对这些原则的取舍。

- 通过牺牲掉某些自己用不上的因素来获取代码的优化，这才是我们在前期编程中所需要思考的。
- 完成对多项原则的协调，达到我们能完善的最好地步，这就是我们中期的目标了。
- 通过合理的架构来包容，完善代码，这大概是我们后期需要达到的目标吧。（Maybe）

## 2、命名方法


### (1) 匈牙利命名：

开头字母用变量类型的缩写，其余部分用变量的英文或英文的缩写，要求单词第一个字母大写。

```
int iMyAge; “i”是int类型的缩写； 
char cMyName[10]; “c”是char类型的缩写； 
float fManHeight; “f”是float类型的缩写；
```

<span id=named_02></span>
### (2) 驼峰式命名法

又叫小驼峰式命名法。 
第一个单词首字母小写，后面其他单词首字母大写。

```
int myAge; 
char myName[10]; 
float manHeight;
```

<span id=named_03></span>
### (3) 帕斯卡命名法

又叫大驼峰式命名法。 
每个单词的第一个字母都大写。

```
int MyAge; 
char MyName[10]; 
float ManHeight;
```
<span id=named_04></span>
### (4) 下划线命名法

在命名中添加下划线用以标识
一般Object-C中建议我们在命名前加`_`，用以区分成员变量与其它变量的

在命名后加`_`，通常用在宏命名中
其它情况下在，`_`添加在标识不同含义的单词块之间用以区分

```
int _myage; 
char my_name[10]; 
__FILE__
```

### 总结

Objective-C 的命名通常都比较长, 名称遵循[驼峰式命名法](#named_02). 一个好的命名标准很简单, 就是做到在开发者一看到名字时, 就能够懂得它的含义和使用方法. 

有些时候这三者也会有起冲突的时候，怎么取舍呢？

借用官方的例子

<span id=TEDC_01></span>

- 表达力 > 简洁

> 尽可能具有表达力和简洁是好的，但是表达力不应该因为简洁而受到影响。

代码|点评
---|---
insertObject:atIndex: | Good
insert:at: | 不清晰;要插⼊什么?“at”表⽰示什么?
removeObjectAtIndex: | Good
removeObject: | 不错,因为⽅法是⽤用来移除作为参数的对象
remove:|不清晰;要移除什么?

- 清晰表达意思

> 一般来说，不要缩写事物的名称。把它们拼出来，即使它们很长:

代码|点评
---|---
destinationSelection| Good
destSel | 不清晰
setBackgroundColor: | Good
setBkgdColor: | 不清晰


- 避免歧义

> 避免API名称中的歧义，例如可以用多种方法解释的方法名

代码|点评
---|---
sendPort| 它是发送端口还是返回?
displayName | 它是在用户界面中显示一个名称还是返回接收者的标题?

需要察看更多的规范，请前往[官方文档](https://developer.apple.com/library/content/documentation/Cocoa/Conceptual/CodingGuidelines/Articles/NamingBasics.html#//apple_ref/doc/uid/20001281-BBCHBFAH)

# 二- 命名规范

## 1、变量命名

### (1) 一般变量命名

<span style="color:#F00">命名方式</span>：【小写类型前缀+`_`+介绍[小驼峰式](#named_02)】的做法。【介绍尽量用自然语言表达自己的意思。】

于个人而言，变量名使用更多的是下划线加驼峰式的命名，尽量用自然语言命名自己的变量

```
@property (nonnull,nonatomic,strong) UIImageView *imageView_head;
```

### (2) 模型内的属性命名

<span style="color:#F00">命名方式</span>：[下划线命名](#named_04)

坚持<span style="color:#F00">一致性</span>的原则

当下后台属性命名方式：[下划线命名](#named_04)
        
对于用于解析后台数据的模型，应尽量保持与后台命名方式一致，最好能命名完全一致
对于用于处理本地数据的模型，也应保持与后台命名方式一致。

<span style="color:#F00">**即应保证具有某一共同功能的类型命名方式一致。**</span>

## 2、类命名

<span style="color:#F00">命名方式</span>：[大驼峰式命名法](#named_03)

对于一般的类，通常是使用大驼峰式的命名方式
类名的拼写方式一般采用<span style="color:#F00">[标识 + 模块名称+功能介绍+类型]</span>

**标识**用于区分其它第三方的类，一般为开发者或者开发公司的标识

**模块名称**标识当前类在界面中所处模块名称

**功能介绍**标识当前类在当前模块中的作用

**类型**标识当前类的类型

其中最有争议的应该是**模块名称**

位置|模块名称
---|---
根控制器|`Base`
一般控制器|其根控制器的**功能介绍**
一般视图|下一级响应者（父视图或是其所属的控制器）的**功能介绍**
通用控制器（例如：登陆、注册或者是好几个`TabBar`分栏都会跳转的控制器）|`public`
通用视图（用于多个界面的视图）| `public`

对控制器而言，模块名称即其根视图的**功能介绍**，若当前控制器即根控制器，则当前控制器的模块标识为`Base`

对于类名，小子是按其在界面中的层次进行命名
对于处于界面第一级的视图 将它的 上一级功能名称的 拼接字段定为`Base`

如`JYBaseHomeViewController` 表示首页的根控制器

其中

标识 |上一级功能 | 功能介绍 | 类型
--- | ---|---|---
`JY` |`Base`|`Home` |`ViewController`

## 3、方法命名

<span style="color:#F00">命名方式</span>：[小驼峰式命名法](#named_02)

方法名应遵守小驼峰原则，首字母小写，其他单词首字母大写,每个空格分割的名称以动词开头。

执行性的方法应该以动词开头，小写字母开头，返回性的方法应该以返回的内容开头，但之前不要加get。

方法名应具备以下特征
### (1) 表达力、简洁

方法名应该是简洁并具有表达力，去除参数之后能形成可读的自然语言
当这二者需要取舍，应该[着重强调表达力](#TEDC_01)

例如：

使用`insertObject:(NSObject*)object  atIndex: (NSInteger)index `

比`insert:(NSObject*)object at: (NSInteger)index`更合适

给它们去掉参数，变成自然语言即 “<span style="color:#F00">insert Object at Index</span>”对“<span style="color:#F00">insert at</span>”，孰优孰劣一目了然

### (2) 只做一件事

当你无法为你的方法起一个准确的名称时，很可能你的方法不止做了一件事，违反了(Do one thing)。

特别是你想在方法名中加入：And，Or，If等词时

```
- (void)RegisterUser:(User*) user SendEmail:(bool)sendEmail
{
    
}
```

此时，应该将执行不同逻辑操作的方法分开，构成两个不同的方法来执行

```
- (void)RegisterUser:(User*)user
{

}

- (void)SendEmail:(User*)user
{

}
```

### (3) 尽可能少的参数

过多的参数让读者难以抓住代码的意图，同时过多的参数将会影响方法的稳定性。另外也预示着参数应该聚合为一个`Model`

参数为<span style="color:#F00">1-2</span>个最合适  

```
- (void) RegisterUserName:(NSString*)userName Password:(NSString*) password Email:(NSString*) email  Phone:(NSString*)phone
{

}
```
此时参数超过3个，可以聚合成为一个模型，以增强可读性

```
- (void) RegisterUser:(User*)user
{

}
```

## 4、类别命名

<span style="color:#F00">命名方式</span>：[类名+标识+扩展（[大驼峰式](#named_03)）]

例：如果我们想要创建一个基于`NSString`的类别用于判断字符串类型，我们应该把类别放到名字是`NSString+JYJudgmentType`的文件里。

`NSString`为要扩展的类名

`JY`为标识

`JudgmentType`为扩展的功能

## 5、枚举的命名

<span style="color:#F00">命名方式</span>：[标识+功能（[大驼峰式](#named_03)）]

类型命名：[枚举名+特征]

下面我们列举一组用于判断字符串类型的枚举

```
typedef NS_ENUM(NSInteger,JYJudgmentType){
    ///数字
    JYJudgmentTypeNumberCharacters             = 1,
    ///英文
    JYJudgmentTypeOrdinaryEnglishCharacters    = 1 << 1,
    ///中文
    JYJudgmentTypeChineseCharacters            = 1 << 2,
    ///电话
    JYJudgmentTypeMobile               = 1 << 3,
    ///身份证
    JYJudgmentTypeIDCard               = 1 << 4,
    ///银行卡
    JYJudgmentTypeBankCard             = 1 << 5,
    ///邮箱
    JYJudgmentTypeEmail             = 1 << 6,
};
```

我们就以`JYJudgmentTypeNumberCharacters`为例

`JY`为标识，`JudgmentType`为该枚举的功能，`NumberCharacters`为当前类型的特征

## 6、const常量

<span style="color:#F00">命名方式</span>：[大驼峰式](#named_03)

如果一定想要和其它变量区分开来，也可以给他一个标识

最明显的例子就是我们常用的`ReuseIdentifier`

## 7、宏命名

<span style="color:#F00">命名方式</span>：[下划线命名](#named_04)+全部字母大写
毕竟官方推荐命名方式

例如系统的宏`__FILE__`
我们也可以加上自己的标识用以和系统的宏区分开来`JY__FILE__`

如果还要标识宏隶属于某一模块的话，还可以更进一步的加上模块的标识`JY__SQL__FILE__`

# 三- 注释规范

> 关于注释，虽说是有很大一份人认为优秀的代码可以完全替代注释，然而在实际上，英语这么强的还是很少的🤦‍♂️。而且对我们来说，用尽可能低的标准来要求别人，项目可维护性。（唔，连中文注释都看不懂那就无解了😒）

注释不用做得太夸张，由于开发中阅读注释大部分都只是为了关联或者了解某项功能，所以我们只需在关键点添加注释即可。

## 1、类前的注释
类的 `.h`文件中添加一段标识注释，用以解释当前类的用法

```
/*
 创建人：（标识创建）
 创建版本：创建类的版本（了解功能在哪一个版本添加或重构）
 功能描述：介绍类的主要功能（让读者一目了然）
 --修改人：（标识功能修改者）
 修改版本：类修改的版本（哪个版本有进行修订）
 修改描述：（修订某一功能）
 ···：重复【修改人 — 修改版本 — 修改描述】三列的介绍。"创建人"在之后的修改过程中也将作为"修改人"
 */
```

## 2、接口注释
推荐使用 `option`+`command`+`/`快捷注释命令
对类的接口处的属性、方法进行介绍

属性：

```
/**
 介绍属性
 */
@property (nonnull,nonatomic,strong) NSObject *object;
```

方法：

```
/**
 介绍方法功能

 @param obj 参数介绍
 */ 
- (void)RegisterUser:(User*)user;
```

## 3、注释标记的使用

`OC`中是有很多的注释标记，就我所知的几个

```
#pragma 编译指示

#warning 警告

//MARK: Method for handing memry managment

//TODO:通知更新，需要做的事

//FIXME: 你想要修改的bug[]()
```

而在诸多标记中，`#pragma mark`应该是使用最广的。

在学习编程的很长一段时间里，我几乎是将这个标记作为万金油的标记来使用的，不管是需要什么提示，都在使用这个标记来记录想要表达的意思。

虽说一直没出什么大问题，而且在表达意思上也不会有太多不明确的地方。

但出于规范，还是建议按照标准的语法来写出自己的注释。

毕竟，在注释方面按规范了对大家都更友好些。

# 四- 逻辑规范

## 1、功能分类明确

对于项目中用到的类、方法等，使用时还需注意尽量将同一类型的类、方法放在相邻位置，做好标识，以便下一次迭代更新时的快速阅读。

接下来就以我们就以在实际开发中最常遇到视图类的逻辑来做例子。

对于封装的视图类，常会用到的方法有三类：

- 添加子视图
- 设置子视图在父视图中的位置
- 人机交互事件的设置

基于此，希望至少在这一种类型封装上能形成规范，当然，能约定俗成是最好的了😄

我就先抛砖引玉了：

首先，重写系统初始化方法，下面是把将普通的init方法和可视化的初始化方法重写，

然后调用我们自己的初始化方法`- (void)commInit`

```
//以frame初始化的方法
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self commInit];
    }
    return self;
}

//以可视化控件初始化的方法
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        [self commInit];
    }
    return self;
}

//自己的初始化方法
- (void)commInit
{

}

```

之后在我们的初始化方法中调用需要的操作，这里我们使用了，子视图添加、约束设置和交互设置三个方法

```
//初始化方法
- (void)commInit
{
    [self theSubViewAdd];
    [self theLayoutSet];
    [self theInterfaceEventSet];
}

//添加子视图
- (void)theSubViewAdd
{

}

//设置约束
- (void)theLayoutSet
{
    
}

//设置交互
- (void)theInterfaceEventSet
{
    
}
```

## 2、代码的重构规范

> 重构是一种对软件进行修改的行为，但它并不改变软件的功能特征，而是通过让软件程序更清晰，更简洁和更条理来改进软件的质量。

代码架构最初的设计也是经过精心的设计，具有良好架构的。

但是随着时间的推移、需求的剧增，必须不断的修改原有的功能、追加新的功能，还免不了有一些缺陷需要修改。

为了实现变更，不可避免的要违反最初的设计构架。

经过一段时间以后，软件的架构就千疮百孔了。

bug越来越多，越来越难维护，新的需求越来越难实现。

最初的代码构架对新的需求渐渐的失去支持能力，而是成为一种制约。

最后新需求的开发成本会超过开发一个新的软件的成本，这就使这个app的生命走到了尽头。

### (1) 目的

 - 持续偏纠和改进软件设计 
 - 使代码更被其他人所理解 
 - 帮助发现隐藏的代码缺陷
 - 从长远来看，有助于提高编程效率，增加项目进度（进度是质量的敌人，质量是进度的朋友） 

### (2) 不适用

- 逻辑看起来过于复杂，没时间去分析梳理。
- 不理解为什么前任程序员要这样编写。 
- 负责的是一个很重要的系统，而且时间很紧。 

### (3) 方式
- 权限分离

对一些“臃肿的类”，应当将其中分属其它类的处理逻辑，应当及时抽离出去。

就以经典`MVC`模式下的赋值为例

有些时候我们会将`Model`层的数据处理逻辑拿到`View`或`Controller`中来用，仅把`Model`层作为一个快速解析、调用数据的工具。

```
    NSString *money = [NSString stringWithFormat:@"总价%@万",_money];
    self.label_money.text = money;
```

而从其各自的业务上来说，数据处理的功能也应放在`Model`层上才是

```
- (NSString *)money
{
    return [NSString stringWithFormat:@"总价%@万",self->_money];
}
```

从另一方面讲，这样的处理在保证单一职责的同时也牺牲掉了数据处理的灵活性。对于相当一部分对灵活性没有太多要求的模块，倒也可以不用在乎这些。

但是，在处理逻辑复杂、对代码的灵活性要求较高的模块中，这种处理方式是完全通过不了我们对代码逻辑可行性的判断。

难道彼时只能大呼“Fuck”，然后回归之前的操作方式？

不！作为程序员，我们可以有很多变通手段的。

那么，如果要兼顾这几种情形，该如何优化呢？

方法其实也很简单，对模型做一个包装，将其中对于数据的处理包装一层，视图层只需要获取包装后的数据就可以直接展示了。

这样的包装也可以算做最简单的`ViewModel`层了。

从这里开始，你也就开始你从`MVC`转到`MVVM`的第一步了。

对，没错！我就是来安利`MVVM`的。😁

- 提取类/方法

适用于以下类：

❶ 与其它类能共用相同的逻辑

❷ 与其它类在架构上一定的相似性

对于这些类可以提取出<span style="color:#F00">专门处理公有逻辑的新类</span>或<span style="color:#F00">架构相似的父类</span>为其减负。

- 利用好第三方代码托管平台

对于某一类在项目间通用性更强的功能模块，更好的使用方式应该是放在第三方托管平台进行托管。做好`Pod`集成和`Carthage`集成的配置

以便 当前功能模块的维护更新以及在下一个项目的快速导入。

# 五- 工具（类）的使用规范

## 1、手写代码 和 Xib的取舍

关于这个问题相信很多同学都有困惑，参考了国内iOS界的大神[唐巧](http://blog.devtang.com/2015/03/22/ios-dev-controversy-2/)和[喵神](https://onevcat.com/2013/12/code-vs-xib-vs-storyboard/)，结合自己在实际开发中的习惯，也就确立之后对于二者的使用了：

- 对于复杂的、动态生成的界面，建议使用手工编写界面。
- 对于需要统一风格的按钮或UI控件，建议使用手工用代码来构造。方便之后的修改和复用。
- 对于需要有继承或组合关系的 UIView 类或 UIViewController 类，建议用代码手工编写界面。
- 对于那些简单的、静态的、非核心功能界面，可以考虑使用 xib 或 storyboard 来完成。

## 2、工具的使用规范

### (1) UI调试工具

对于UI的调试，据我所知的有两种：

[Reveal](https://revealapp.com)和[UIDebuggingInformationOverlay](http://ryanipete.com/blog/ios/swift/objective-c/uidebugginginformationoverlay/)

二者的用法同等便利，但[Reveal](https://revealapp.com)比起[UIDebuggingInformationOverlay](http://ryanipete.com/blog/ios/swift/objective-c/uidebugginginformationoverlay/)来功能无疑是丰富许多。

[UIDebuggingInformationOverlay](http://ryanipete.com/blog/ios/swift/objective-c/uidebugginginformationoverlay/)现有的功能：

1. 列出界面层次、视图位置、从属关系
2. 对比设计图与APP运行时界面
3. 获取界面上的目标约束

[Reveal](https://revealapp.com)仅咱现在用到的功能在[UIDebuggingInformationOverlay](http://ryanipete.com/blog/ios/swift/objective-c/uidebugginginformationoverlay/)功能的基础上多了：

1. 使用可视化的图来展示界面的层次
2. GUI 上动态改变约束可以直接应用到APP上，实时展示改变效果（个人感觉这一点对后期UI的优化还是有点帮助的）
3. 对于越狱的机器，可以用Reveal来”调试“其它应用界面

所以说哟，能使用[Reveal](https://revealapp.com)还是用它为好，

[UIDebuggingInformationOverlay](http://ryanipete.com/blog/ios/swift/objective-c/uidebugginginformationoverlay/)更多是在懒得使用或者实在用了[Reveal](https://revealapp.com)的时候再用好了😦

### (2) 逻辑调试

断言作为`Objective-C`中居重要地位的调试工具，还是推荐大家多多使用的。

网上关于断言使用的介绍很多，这里也就不一一叙述了。

由于Xcode 已经默认将`release`环境下的断言取消了, 免除了忘记关闭断言造成的程序不稳定.

因此，我们可以在开发环境中尽可能的利用断言来进行项目调试。

同时，也能通过断言来体验TDD模式下的开发。

### (3) 图片添加工具

某些特定的适合或许可以试下（设计很不靠谱的时候）[Asset Catalog Creator](https://itunes.apple.com/cn/app/asset-catalog-creator-free/id866571115?mt=12)，

一键设置Icon，直接添加到系统资源库,简单粗暴。

有些人也许一辈子都用不上吧。

### (4) 项目优化工具

会用Xcode那对Intrument一定不会陌生了，也不多说，要优化就尽量多用吧。

### (5) 第三方代码托管

终归还是[Github](https://github.com/)通用性最强，各种强大的工具都能找到

[码市](https://coding.net)反正我是没怎么用过的

# 六- 项目的基本架构

```
    ├── <Supporting Files>(放置预编译文件、系统配置文件和`APPDelegate.*`类)
    ├── <Utils>（适用于本项目的自定义类库。根据功能可以细分下去。例如：UI类、Data类、Net类）
    ├── <BaseController>（控制器的基类，方能统一管理控制器的各项特征）
    ├── <TabBarController>（窗口根控制器）
    ├── <CodeClass>（项目真正的构建内容）
    └── <Pods（或Carthage）>工程（第三方SDK以及自己做的小工具）
```

在XCode上创建时，如果有个比较清晰的层级构建，将对以后的项目维护和功能的拓展很有帮助。

这次，将简要描述对项目层级的拙见。

## 1、CocoaPods

关于第三方的工具，想必大家现在都用的是第三方的管理工具来进行集成。比较出名的就是`CocoaPods`和`Carthage`，惭愧的是咱还完全没了解过`Carthage`（懒过头了点 ..😄）。所以唯一能说的也就是`CocoaPods`了。

`Pods`不仅仅只是用来集成别人的工具，也是能用管理、集成自己的工具。

别怕自己的代码放到[Github](https://github.com/)上被人笑话，传上去的初衷是为了便利自己而已，其它什么的都是添头。

想想，你做了个小工具，之后创建好几个项目的时候都是一个个拖进去，之后可能发现其中的逻辑出来了致命的bug。

难道优化之后，还得一个个的项目拖过去？

省省把，工具本来就是帮我们提升开发效率的，将这么强大的功能弃置不顾，仅仅把它作为一个便利的获取轮子的工具，确实该自省了！

## 2、Supporting Files

对于些系统的配置文件 `Info.plist`、`InfoPlist.strings`和预编译的文件`.pch`、`header File`以及`main.m`主函数。

通常我们在项目创建之后，对这些文件的访问频率都会很低的，因此可以将它们都放做一块，统一管理。

## 3、Utils

对于适用性很小，仅在当前项目中通用的工具类。我们统一放在Utils类目下，分门别类的列出来。

## 4、BaseController

放置控制器的基类，方能统一管理控制器的各项特征。

项目中应该是尽量少的创建基类，否则项目内部模块的耦合性会达到自己都不能理清的地步。

## 4、TabBarController

对于窗口的根控制器，它的位置是有点尴尬。

作为项目中实际存在一个控制器，它应该放在`CodeClass`里面，但这样也将这类目强行加了一层。

作为一个创建之后就确定的，不会轻易改变的类，它也可以放置在`Supporting Files`里。

既然都不好下决定，索性就新开一层，专门放置好了。

## 5、CodeClass

项目构建的实际结构，按照界面层次逐层的创建下去。

其内部构架就按经典`MVC`，分类的文件夹直接标以`M`、`V`、`C`，对模块的构架就一目了然了。

# 结语

代码的规范不是一两天能成型的，需要持之以恒的进行思考、优化。

其它人的思路只能是一种参考，用以印证自己所学的局限，实际开发之后还是需要找到自己的思路，将别人的思路作为养分来浇灌自己的思路。

记住，我们所要强化的永远都是自己，别总想把自己变成其它人。

我们的目标是，星辰大海哟～！

---<span style="font-size:2rem">END</span>---

 References:
 
 [三种编程命名规范（匈牙利命名法、驼峰式命名法、帕斯卡命名法）](http://blog.csdn.net/f_zyj/article/details/51510085)
 
[编写让别人能够读懂的代码](http://www.cnblogs.com/richieyang/p/4840614.html)

[IOS开发（OC）中的命名规范](http://www.cnblogs.com/iOS-mt/p/5445284.html)

[Objective-C开发编码规范](http://www.cocoachina.com/ios/20150508/11780.html)

[iOS开发总结之代码规范](http://www.jianshu.com/p/414bb5a53139)

[iOS开发代码规范(通用)](http://www.cnblogs.com/gfxxbk/p/5469017.html)

[iOS中书写代码规范35条小建议](http://www.jianshu.com/p/71fdd1ae714c)


[iOS 开发中的争议（二）](http://blog.devtang.com/2015/03/22/ios-dev-controversy-2/)

[代码手写UI，xib和StoryBoard间的博弈，以及Interface Builder的一些小技巧](https://onevcat.com/2013/12/code-vs-xib-vs-storyboard/)


[iOS项目重构周记（一）](http://www.jianshu.com/p/395700466a7b)

[代码重构意义和方法](http://blog.csdn.net/justinjing0612/article/details/41311577)

[IOS整体项目层级构建](http://www.cnblogs.com/wujy/p/5104111.html)

[DRY原则的危害](http://www.jianshu.com/p/87fc1079d596)

[Xcode TODO MARK FIXME 标记](http://blog.csdn.net/a1056244734/article/details/50894199)

[程序异常处理----- 断言NSAssert()和NSParameterAssert区别和用处](http://www.cnblogs.com/CoderAlex/p/6186599.html)

[iOS - 断言处理与调试](http://www.jianshu.com/p/7cea580441d3)

